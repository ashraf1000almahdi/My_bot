// Dashboard JavaScript functionality

// Initialize dashboard
document.addEventListener('DOMContentLoaded', function() {
    initializeDashboard();
    setupEventListeners();
});

function initializeDashboard() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    const tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    const popoverList = popoverTriggerList.map(function(popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Setup auto-refresh
    setupAutoRefresh();
}

function setupEventListeners() {
    // Search functionality
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', debounce(handleSearch, 300));
    }

    // Filter dropdowns
    const filterSelects = document.querySelectorAll('.filter-select');
    filterSelects.forEach(select => {
        select.addEventListener('change', handleFilterChange);
    });

    // Bulk actions
    const bulkActionButtons = document.querySelectorAll('.bulk-action-btn');
    bulkActionButtons.forEach(button => {
        button.addEventListener('click', handleBulkAction);
    });

    // Check all checkbox
    const checkAllBox = document.getElementById('checkAll');
    if (checkAllBox) {
        checkAllBox.addEventListener('change', handleCheckAll);
    }

    // Individual checkboxes
    const checkboxes = document.querySelectorAll('.item-checkbox');
    checkboxes.forEach(checkbox => {
        checkbox.addEventListener('change', handleIndividualCheck);
    });

    // Export buttons
    const exportButtons = document.querySelectorAll('.export-btn');
    exportButtons.forEach(button => {
        button.addEventListener('click', handleExport);
    });

    // Refresh buttons
    const refreshButtons = document.querySelectorAll('.refresh-btn');
    refreshButtons.forEach(button => {
        button.addEventListener('click', handleRefresh);
    });
}

function setupAutoRefresh() {
    // Auto-refresh stats every 30 seconds
    setInterval(() => {
        updateStats();
    }, 30000);

    // Auto-refresh processing items every 10 seconds
    setInterval(() => {
        updateProcessingItems();
    }, 10000);
}

function updateStats() {
    fetch('/api/stats')
        .then(response => response.json())
        .then(data => {
            // Update stat cards
            updateStatCard('total-users', data.total_users);
            updateStatCard('total-downloads', data.total_downloads);
            updateStatCard('successful-downloads', data.successful_downloads);
            updateStatCard('failed-downloads', data.failed_downloads);
            updateStatCard('success-rate', data.success_rate + '%');
        })
        .catch(error => {
            console.error('Error updating stats:', error);
        });
}

function updateStatCard(cardId, value) {
    const card = document.getElementById(cardId);
    if (card) {
        const valueElement = card.querySelector('.stat-value');
        if (valueElement) {
            valueElement.textContent = value;
        }
    }
}

function updateProcessingItems() {
    const processingItems = document.querySelectorAll('[data-status="processing"]');
    processingItems.forEach(item => {
        const itemId = item.getAttribute('data-item-id');
        const itemType = item.getAttribute('data-item-type');
        
        if (itemId && itemType) {
            checkItemStatus(itemId, itemType);
        }
    });
}

function checkItemStatus(itemId, itemType) {
    fetch(`/api/${itemType}/${itemId}`)
        .then(response => response.json())
        .then(data => {
            if (data.status !== 'processing') {
                // Reload the page to reflect changes
                location.reload();
            }
        })
        .catch(error => {
            console.error('Error checking item status:', error);
        });
}

function handleSearch(event) {
    const searchTerm = event.target.value.toLowerCase();
    const tableRows = document.querySelectorAll('tbody tr');
    
    tableRows.forEach(row => {
        const text = row.textContent.toLowerCase();
        const isVisible = text.includes(searchTerm);
        row.style.display = isVisible ? '' : 'none';
    });
}

function handleFilterChange(event) {
    const filterValue = event.target.value;
    const filterType = event.target.getAttribute('data-filter-type');
    
    // Update URL with filter parameters
    const url = new URL(window.location);
    url.searchParams.set(filterType, filterValue);
    window.history.pushState({}, '', url);
    
    // Reload page with new filter
    location.reload();
}

function handleBulkAction(event) {
    const action = event.target.getAttribute('data-action');
    const checkedItems = getCheckedItems();
    
    if (checkedItems.length === 0) {
        showAlert('يرجى اختيار عنصر واحد على الأقل', 'warning');
        return;
    }
    
    if (confirm(`هل تريد تطبيق "${action}" على ${checkedItems.length} عنصر؟`)) {
        performBulkAction(action, checkedItems);
    }
}

function getCheckedItems() {
    const checkboxes = document.querySelectorAll('.item-checkbox:checked');
    return Array.from(checkboxes).map(checkbox => checkbox.value);
}

function performBulkAction(action, items) {
    const data = {
        action: action,
        items: items
    };
    
    fetch('/api/bulk-action', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
        if (result.success) {
            showAlert(result.message, 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showAlert(result.message, 'danger');
        }
    })
    .catch(error => {
        console.error('Error performing bulk action:', error);
        showAlert('حدث خطأ أثناء تنفيذ العملية', 'danger');
    });
}

function handleCheckAll(event) {
    const checkboxes = document.querySelectorAll('.item-checkbox');
    checkboxes.forEach(checkbox => {
        checkbox.checked = event.target.checked;
    });
    updateBulkActionButtons();
}

function handleIndividualCheck() {
    const checkboxes = document.querySelectorAll('.item-checkbox');
    const checkedCount = document.querySelectorAll('.item-checkbox:checked').length;
    const checkAllBox = document.getElementById('checkAll');
    
    if (checkAllBox) {
        checkAllBox.checked = checkedCount === checkboxes.length;
        checkAllBox.indeterminate = checkedCount > 0 && checkedCount < checkboxes.length;
    }
    
    updateBulkActionButtons();
}

function updateBulkActionButtons() {
    const checkedCount = document.querySelectorAll('.item-checkbox:checked').length;
    const bulkActionButtons = document.querySelectorAll('.bulk-action-btn');
    
    bulkActionButtons.forEach(button => {
        button.disabled = checkedCount === 0;
        const countSpan = button.querySelector('.count');
        if (countSpan) {
            countSpan.textContent = checkedCount;
        }
    });
}

function handleExport(event) {
    const exportType = event.target.getAttribute('data-export-type');
    const format = event.target.getAttribute('data-format') || 'csv';
    
    // Show loading state
    const button = event.target;
    const originalText = button.innerHTML;
    button.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>جاري التصدير...';
    button.disabled = true;
    
    // Perform export
    fetch(`/api/export/${exportType}?format=${format}`)
        .then(response => {
            if (response.ok) {
                return response.blob();
            }
            throw new Error('Export failed');
        })
        .then(blob => {
            // Create download link
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${exportType}_${new Date().toISOString().split('T')[0]}.${format}`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            
            showAlert('تم تصدير البيانات بنجاح', 'success');
        })
        .catch(error => {
            console.error('Export error:', error);
            showAlert('حدث خطأ أثناء تصدير البيانات', 'danger');
        })
        .finally(() => {
            // Restore button state
            button.innerHTML = originalText;
            button.disabled = false;
        });
}

function handleRefresh(event) {
    event.preventDefault();
    
    const button = event.target;
    const originalText = button.innerHTML;
    button.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>جاري التحديث...';
    button.disabled = true;
    
    setTimeout(() => {
        location.reload();
    }, 1000);
}

function showAlert(message, type = 'info') {
    const alertContainer = document.querySelector('.alert-container') || document.querySelector('.container');
    const alertId = 'alert-' + Date.now();
    
    const alertHTML = `
        <div id="${alertId}" class="alert alert-${type} alert-dismissible fade show" role="alert">
            <i class="fas fa-${getAlertIcon(type)} me-2"></i>
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    `;
    
    alertContainer.insertAdjacentHTML('afterbegin', alertHTML);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        const alertElement = document.getElementById(alertId);
        if (alertElement) {
            const bsAlert = bootstrap.Alert.getOrCreateInstance(alertElement);
            bsAlert.close();
        }
    }, 5000);
}

function getAlertIcon(type) {
    const icons = {
        'success': 'check-circle',
        'danger': 'exclamation-triangle',
        'warning': 'exclamation-triangle',
        'info': 'info-circle'
    };
    return icons[type] || 'info-circle';
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Utility functions
function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 بايت';
    
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['بايت', 'كيلوبايت', 'ميجابايت', 'جيجابايت', 'تيرابايت'];
    
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(() => {
        showAlert('تم نسخ النص إلى الحافظة', 'success');
    }).catch(err => {
        console.error('Failed to copy text: ', err);
        showAlert('فشل في نسخ النص', 'danger');
    });
}

// Global functions for inline event handlers
window.viewUser = function(userId) {
    // Implementation moved to users.html
};

window.viewDownload = function(downloadId) {
    // Implementation moved to downloads.html
};

window.checkSubscription = function(userId) {
    // Implementation moved to users.html
};

window.retryDownload = function(downloadId) {
    // Implementation moved to downloads.html
};

window.exportUsers = function() {
    // Implementation moved to users.html
};

window.exportDownloads = function() {
    // Implementation moved to downloads.html
};

window.refreshUsers = function() {
    location.reload();
};

window.refreshDownloads = function() {
    location.reload();
};

// Real-time updates using WebSocket (if available)
if (typeof WebSocket !== 'undefined') {
    const wsProtocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${wsProtocol}//${window.location.host}/ws`;
    
    try {
        const ws = new WebSocket(wsUrl);
        
        ws.onmessage = function(event) {
            const data = JSON.parse(event.data);
            handleWebSocketMessage(data);
        };
        
        ws.onerror = function(error) {
            console.log('WebSocket error:', error);
        };
        
        ws.onclose = function() {
            console.log('WebSocket connection closed');
        };
    } catch (error) {
        console.log('WebSocket not available:', error);
    }
}

function handleWebSocketMessage(data) {
    switch (data.type) {
        case 'stats_update':
            updateStats();
            break;
        case 'new_user':
            showAlert(`مستخدم جديد: ${data.user.display_name}`, 'info');
            break;
        case 'download_complete':
            showAlert(`تم إكمال تحميل: ${data.download.title}`, 'success');
            break;
        case 'download_failed':
            showAlert(`فشل تحميل: ${data.download.title}`, 'warning');
            break;
        default:
            console.log('Unknown WebSocket message type:', data.type);
    }
}

// Performance monitoring
if ('performance' in window) {
    window.addEventListener('load', () => {
        setTimeout(() => {
            const perfData = window.performance.timing;
            const loadTime = perfData.loadEventEnd - perfData.navigationStart;
            console.log(`Page load time: ${loadTime}ms`);
        }, 0);
    });
}

// Service Worker registration (for caching)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/service-worker.js')
            .then(registration => {
                console.log('SW registered: ', registration);
            })
            .catch(registrationError => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        updateStats,
        showAlert,
        formatBytes,
        formatDate,
        copyToClipboard
    };
}
